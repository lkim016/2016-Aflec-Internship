<footer>
	<div class = "footerContain">
		<table>
			<tr>
				<th class = "column1">EVERWELL PASADENA</th>
				<th class = "column2">CONTACT YOUR AGENT</th>
				<th class = "column3">FOLLOW</th>
			</tr>
			<tr>
				<td class = "column1">
					<p>1 S FAIR OAKS AVE.</br>SUITE #200,</br>PASADENA, CA 91105</p>
					<p>PHONE: (626) 796-7077</br>
					FAX: (626) 796-7060</p>
				</td>
				<td class = "column2">
					<form action>
						<p> <input name = "email" type = "text" placeholder = "E-mail address" /> </p>
						<p> <input name = "subject" type = "text" placeholder = "Subject" /> </p>
						<p> <textarea name = "message" type = "text" /></textarea> </p>
						<p> <input name = "btnsubmit" type = "submit" />
					</form>
				</td>
				<td class = "column3">
					<div>
            <a href="https://www.facebook.com/Everwell-Pasadena-1548917178752690/?ref=hl" class="facebook_img"><img name="fbImage" src="http://www.everwellpasadenabeta.com/wp-content/uploads/2016/03/contact-us-fb.png"></a>
					</div>
					<div>
            <a href="https://twitter.com/EverwelPasadena/" class="twitter_img"><img name="twitImage" src="http://www.everwellpasadenabeta.com/wp-content/uploads/2016/03/contact-us-twitter.png"></a>
					</div>
					<div>
            <a href="https://www.instagram.com/everwellpasadena/" class="instagram_img"><img name="instaImage" src="http://www.everwellpasadenabeta.com/wp-content/uploads/2016/03/contact-us-instagram.png"></a>
					</div>
				</td>
			</tr>
				<!--- ONLY VISIBLE ON MOBILE -->
			<tr>
				<td class = "mobCol">
					<div>
            <a href="https://www.facebook.com/Everwell-Pasadena-1548917178752690/?ref=hl" class="facebook_img"><img align = "left" name="fbImage" src="http://www.everwellpasadenabeta.com/wp-content/uploads/2016/03/contact-us-fb.png"></a>
            <a href="https://twitter.com/EverwelPasadena/" class="twitter_img"><img name="twitImage" align = "middle" src="http://www.everwellpasadenabeta.com/wp-content/uploads/2016/03/contact-us-twitter.png"></a>
            <a href="https://www.instagram.com/everwellpasadena/" class="instagram_img"><img name="instaImage" align = "right" src="http://www.everwellpasadenabeta.com/wp-content/uploads/2016/03/contact-us-instagram.png"></a>
          </div>
				</td>
			</tr>
		</table>
	</div>
</footer>


</html>