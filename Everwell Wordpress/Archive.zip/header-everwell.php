<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!--<meta name="viewport" content="initial-scale=1"> //this messes up mobile formatting-->
	<title>Test</title>

<link rel="stylesheet" type="text/css" href="style.css"/>
<link rel="stylesheet" type="text/css" href="normalize.css">
</head>


<header>
	<div id="headerWrapper">
		<div class="header">
		<!-- Alfac and Everwell logos go here -->
			<img src="http://www.everwellpasadenabeta.com/wp-content/uploads/2016/03/aflacLogo.png" alt="Aflac Main Logo" class="flexbox-item aflac-logo">
			<img src="http://www.everwellpasadenabeta.com/wp-content/uploads/2016/03/everwell-logo.png" alt="Everwell Main Logo" class="flexbox-item ever-logo">
			<!-- Blue Box goes here -->
			<section class="blue-box">
				<div class="guyDiv">	
					<img class="guy" src="http://www.everwellpasadenabeta.com/wp-content/uploads/2016/03/guy.png" alt="Picture in blue box">
				</div>	
        <div class="tableWrap">
					<div class="acc-dates">
						<h1>ACCOUNT</h1>
					</div>	
						<!-- Tabs -->
			<div class="tabsHeader">
			    <div class="tabHeader">
			       <input type="radio" id="tab-1" name="tab-group-1" checked>
			       <label class="tabz" for="tab-1">AGENT</label>
			       <div class="content">
			           AGENT
			       </div> 
			    </div>
			   <div class="tabHeader">
			       <input type="radio" id="tab-2" name="tab-group-1">
			       <label class="tabz" for="tab-2">DATES</label>       
			       <div class="contentHeader">
			           DATES
			       </div> 
			   </div>
			</div> 
      </div>  
			 <!-- end of tabs -->
			</section>
		</div>					
	</div>
</header>