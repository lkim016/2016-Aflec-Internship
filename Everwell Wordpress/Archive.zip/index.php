<?php /* Template Name: CustomPageT1 */ ?> 

<?php get_header(); ?>

    <!---BODY-->
<body>
      <div id="popup" class="popup_content">
        <p class="popup_Title"><b>Policy Title</b></p>
        <p id="popuptext" class="popup_Text">
        &emsp;Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><br>
        <ul>
          <li>Lorem ipsum dolor sit amet</li>
          <li>Lorem ipsum dolor sit amet</li>
          <li>Lorem ipsum dolor sit amet</li>
          <li>Lorem ipsum dolor sit amet</li>
        </ul>
     <a id="popupClose" class = "popup_Close" href = "javascript:void(0)" onclick = "document.getElementById('popup').style.display='none';document.getElementById('fade').style.display='none'">Close</a></div>

    <div id="fade" class="black_overlay"></div>  
          <div class="service-text" id="service-text">

            <div class="service-container">

           	  <div class="job-column-1 job-column-2 job-column-3">
              <a href = "javascript:void(0)" onclick = "document.getElementById('popup').style.display='block';document.getElementById('fade').style.display='block'">
                	<div class="service-item">
  							  <div class="service-thumb">
  								<div class="overlay-p">
  								</div>
  						  	</div> <!-- /.service-thumb -->
                  <p><b>SHORT-TERM POLICY</b><br>
                  <font class="learnFont" size="2">Learn More ></font></p>
  						  </div>
             </a>
              </div>
              <div class="job-column-1 job-column-2 job-column-3">
              <a href = "javascript:void(0)" onclick = "document.getElementById('popup').style.display='block';document.getElementById('fade').style.display='block'">
                  <div class="service-item">
                  <div class="service-thumb">
                  <div class="overlay-p">
                  </div>
                  </div> <!-- /.service-thumb -->
                  <p><b>SHORT-TERM POLICY</b><br>
                  <font class="learnFont" size="2">Learn More ></font></p>
                </div>
             </a>
              </div>
             <div class="job-column-1 job-column-2 job-column-3">
             <a href = "javascript:void(0)" onclick = "document.getElementById('popup').style.display='block';document.getElementById('fade').style.display='block'">
                  <div class="service-item">
                  <div class="service-thumb">
                  <div class="overlay-p">
                  </div>
                  </div> <!-- /.service-thumb -->
                  <p><b>SHORT-TERM POLICY</b><br>
                  <font class="learnFont" size="2">Learn More ></font></p>
                </div>
             </a>
              </div>
            <div class="job-column-1 job-column-2 job-column-3">
              <a href = "javascript:void(0)" onclick = "document.getElementById('popup').style.display='block';document.getElementById('fade').style.display='block'">
                  <div class="service-item">
                  <div class="service-thumb">
                  <div class="overlay-p">
                  </div>
                  </div> <!-- /.service-thumb -->
                  <p><b>SHORT-TERM POLICY</b><br>
                  <font class="learnFont" size="2">Learn More ></font></p>
                </div>
             </a>
              </div>

             <div class="job-column-1 job-column-2 job-column-3">
              <a href = "javascript:void(0)" onclick = "document.getElementById('popup').style.display='block';document.getElementById('fade').style.display='block'">
                  <div class="service-item">
                  <div class="service-thumb">
                  <div class="overlay-p">
                  </div>
                  </div> <!-- /.service-thumb -->
                  <p><b>SHORT-TERM POLICY</b><br>
                  <font class="learnFont" class="learnFont" size="2">Learn More ></font></p>
                </div>
             </a>
              </div>
            <div class="job-column-1 job-column-2 job-column-3">
              <a href = "javascript:void(0)" onclick = "document.getElementById('popup').style.display='block';document.getElementById('fade').style.display='block'">
                  <div class="service-item">
                  <div class="service-thumb">
                  <div class="overlay-p">
                  </div>
                  </div> <!-- /.service-thumb -->
                  <p><b>SHORT-TERM POLICY</b><br>
                  <font class="learnFont" size="2">Learn More ></font></p>
                </div>
             </a>
              </div>
            <div class="job-column-1 job-column-2 job-column-3">
              <a href = "javascript:void(0)" onclick = "document.getElementById('popup').style.display='block';document.getElementById('fade').style.display='block'">
                  <div class="service-item">
                  <div class="service-thumb">
                  <div class="overlay-p">
                  </div>
                  </div> <!-- /.service-thumb -->
                  <p><b>SHORT-TERM POLICY</b><br>
                  <font class="learnFont" size="2">Learn More ></font></p>
                </div>
             </a>
              </div>
             <div class="job-column-1 job-column-2 job-column-3">
              <a href = "javascript:void(0)" onclick = "document.getElementById('popup').style.display='block';document.getElementById('fade').style.display='block'">
                  <div class="service-item">
                  <div class="service-thumb">
                  <div class="overlay-p">
                  </div>
                  </div> <!-- /.service-thumb -->
                  <p><b>SHORT-TERM POLICY</b><br>
                  <font class="learnFont" size="2">Learn More ></font></p>
                </div>
             </a>
              </div>
              <div class="job-column-1 job-column-2 job-column-3">
              <a href = "javascript:void(0)" onclick = "document.getElementById('popup').style.display='block';document.getElementById('fade').style.display='block'">
                  <div class="service-item">
                  <div class="service-thumb">
                  <div class="overlay-p">
                  </div>
                  </div> <!-- /.service-thumb -->
                  <p><b>SHORT-TERM POLICY</b><br>
                  <font class="learnFont" size="2">Learn More ></font></p>
                </div>
             </a>
              </div>
              <div class="job-column-1 job-column-2 job-column-3">
              <a href = "javascript:void(0)" onclick = "document.getElementById('popup').style.display='block';document.getElementById('fade').style.display='block'">
                  <div class="service-item">
                  <div class="service-thumb">
                  <div class="overlay-p">
                  </div>
                  </div> <!-- /.service-thumb -->
                  <p><b>SHORT-TERM POLICY</b><br>
                  <font class="learnFont" size="2">Learn More ></font></p>
                </div>
             </a>
              </div>
             <div class="job-column-1 job-column-2 job-column-3">
              <a href = "javascript:void(0)" onclick = "document.getElementById('popup').style.display='block';document.getElementById('fade').style.display='block'">
                  <div class="service-item">
                  <div class="service-thumb">
                  <div class="overlay-p">
                  </div>
                  </div> <!-- /.service-thumb -->
                  <p><b>SHORT-TERM POLICY</b><br>
                  <font class="learnFont" size="2">Learn More ></font></p>
                </div>
             </a>
              </div>
             <div class="job-column-1 job-column-2 job-column-3">
              <a href = "javascript:void(0)" onclick = "document.getElementById('popup').style.display='block';document.getElementById('fade').style.display='block'">
                  <div class="service-item">
                  <div class="service-thumb">
                  <div class="overlay-p">
                  </div>
                  </div> <!-- /.service-thumb -->
                  <p><b>SHORT-TERM POLICY</b><br>
                  <font class="learnFont" size="2">Learn More ></font></p>
                </div>
             </a>
              </div>


    </div>
</div>
<div class="register_div">
  <a href="https://www.everwellbenefits.com" class="registerButton">REGISTER FOR ENROLLMENT</a>

</div>


</body>

<!-- END OF BODY -->

<?php get_footer(); ?>

